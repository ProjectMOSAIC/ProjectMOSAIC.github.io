#' US Mortality table from 2007
#'
"SSA_2007"
