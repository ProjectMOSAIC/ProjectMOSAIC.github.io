#' Run the sandbox app locally
#'
#' @export
Sandbox <- function() {
  learnr::run_tutorial('Sandbox', package='Zcalc')
}
