#' Plot functions of one and two variables using lattice system
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{plotFun}}
#' @name plotFun
NULL
