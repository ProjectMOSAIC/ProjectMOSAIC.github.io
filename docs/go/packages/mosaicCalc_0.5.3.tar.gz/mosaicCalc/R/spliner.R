#' Construct a spline function going through a set of points
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{spliner}}.
#' @name spliner
NULL
