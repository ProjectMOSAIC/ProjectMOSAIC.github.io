#' Create an interpolating function going through a set of points
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{connector}}.
#' @name connector
NULL
