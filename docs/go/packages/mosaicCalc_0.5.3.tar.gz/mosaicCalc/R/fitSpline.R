#' Find zeros of a function
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{fitSpline}}
#' @name fitSpline
NULL
