context('Inline expansion of functions in formulas')

test_that("inline expansion of functions embedded in tilde works", {
  # these should be literally identical, since they are symbolic
  f <- makeFun(tan(sqrt(x^2)) ~ x)
  ff <- makeFun(pnorm(cos(x)) ~ x)
  fff <- makeFun(3 + 2*x ~ x)

  fun1 <- ff(f(x)) ~ x
  fun2 <- fff(f(fff(x))) ~ x
  fun3 <- ff(ff(fff(f(x)))) + f(ff(fff(x)))*x ~ x

  xpts <- rnorm(10)
  mf1 <- makeFun(fun1)
  mf2 <- makeFun(fun2)
  mf3 <- makeFun(fun3)
  xf1 <- makeFun(make_tilde_inline(fun1))
  xf2 <- makeFun(make_tilde_inline(fun2))
  xf3 <- makeFun(make_tilde_inline(fun3))
  expect_equal(
    mf1(xpts), # direct from the formula, no inlining
    xf1(xpts) # with inlining
  )
  expect_equal(
    mf2(xpts), # direct from the formula, no inlining
    xf2(xpts) # with inlining
  )
  expect_equal(
    mf3(xpts), # direct from the formula, no inlining
    xf3(xpts) # with inlining
  )

})
