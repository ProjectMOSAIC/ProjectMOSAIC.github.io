#' Generate a "natural looking" function of one or multiple variables
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{rfun}}.
#' @name rfun
NULL
