#' Find zeros of a function
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{findZeros}}
#' @name findZeros
NULL
