#' Create a smoothing function approximating a cloud of points
#'
#' This is defined in the `mosaic package`:
#' See \code{\link[mosaic]{smoother}}.
#' @name smoother
NULL
