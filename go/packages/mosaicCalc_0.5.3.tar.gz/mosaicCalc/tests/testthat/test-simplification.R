context('Simplification works')

f1 <- makeFun(x*x*(1+x) ~ x)
f2 <- makeFun((3*x)*4*x ~ x)
f3 <- D(dnorm(x) ~ x & x & x)
s1 <- simplify_fun(f1)
s2 <- simplify_fun(f2)
s3 <- simplify_fun(f3)
xpts <- rnorm(10)

test_that("simplify_mult() produces equivalent of original input", {
  expect_equal(f1(xpts), s1(xpts))
  expect_equal(f2(xpts), s2(xpts))
  expect_equal(f3(xpts), s3(xpts))
})
