# mosaicCalc package NEWS

## mosaicCalc 0.5.0

 * Calculus materials separated from the `mosaic` package and housed here.
 * Reconfigured `mosaicCalc` as a separate package that works with the `mosaicCore` ecosystem.
 
## mosaicCalc 0.5.1

 * Added cross-references to calculus functions in `mosaic`
 * Internal functions no longer show up in package documentation.
 * Added a vignette oriented toward instructors.
 * Fixed reversal of axes in `interactive_plot()`

## mosaicCalc 0.5.2

  * added `surface_with_contours()`.
  * added `vectorfield_plot()` and `gradient_plot()`
  
## mosaicCalc 0.5.3

  * fixed label colors and alpha in `slice_plot()`
  * contour_plot() now uses boxed labels instead of plain text for contour marking 
  * slice_plot() adds a "singularities" argument to insert breaks in the graph. 
  * more flexible domain specification for slice_plot and contour_plot
  * can use expressions instead of formulas for makeFun()
  
